﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Clear();
            txtValC.Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValA.Text, out ladoA))
            {
                MessageBox.Show("Valor A Inválido.");
            }
            else
                 if (ladoA <= 0)
            {
                MessageBox.Show("Digite um número maior que ZERO.");
            }
        }

        private void txtValB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValB.Text, out ladoB))
            {
                MessageBox.Show("Valor B Inválido.");
            }
            else
                if (ladoB <= 0)
            {
                MessageBox.Show("Digite um número maior que ZERO.");
            }
        }

        private void txtValC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValC.Text, out ladoC))
            {
                MessageBox.Show("Valor C Inválido.");
            }
            else
                if (ladoC <= 0)
            {
                MessageBox.Show("Digite um número maior que ZERO.");
            }
        }
        private void btnVer_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtValA.Text, out ladoA) && double.TryParse(txtValB.Text, out ladoB) && double.TryParse(txtValC.Text, out ladoC))
            {
                bool validarA = ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC);
                bool validarB = ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC);
                bool validarC = ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB);

                if (!(validarA && validarB && validarC))
                {
                    MessageBox.Show("Valores inseridos não formam um triângulo");
                }
                else
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                        MessageBox.Show("Triângulo Equilátero");

                    else if (ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                        MessageBox.Show("Triângulo Escaleno");

                    else
                        MessageBox.Show("Triângulo Isósceles");
                }
            }
        }
    }
}