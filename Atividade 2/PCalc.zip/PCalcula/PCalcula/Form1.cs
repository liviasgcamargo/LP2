﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalcula
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, resultado;
        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Número 2 Inválido!");
            }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtNum1.Text, out numero1)) && (Double.TryParse(txtNum2.Text, out numero2)));
            {
                resultado = numero1 + numero2;
                txtResul.Text = resultado.ToString();
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtNum1.Text, out numero1)) && (double.TryParse(txtNum2.Text, out numero2)));
            {
                resultado = numero1 - numero2;
                txtResul.Text = resultado.ToString();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out numero1) && (double.TryParse(txtNum2.Text, out numero2))) ;
            {
                resultado = numero1 * numero2;
                txtResul.Text = resultado.ToString();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtNum1.Text, out numero1)) && (double.TryParse(txtNum2.Text, out numero2)) && (numero2 != 0))
            {
                resultado = numero1 / numero2;
                txtResul.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Divisão por zero");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
                txtNum1.Clear();
                txtNum2.Clear();
                txtResul.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("Número 1 Inválido!");
            }
        }
    }
}
