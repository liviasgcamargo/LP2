﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalário
{
    public partial class Form1 : Form
    {
        double salBruto, salFamilia, aliqINSS, aliqIRPF, descINSS, descIRPF;
        int numFilhos;
        char Nome;

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNome.Text)) ;
            {
                MessageBox.Show("Preencha o campo com o seu Nome Completo.");

                {
                    if (!double.TryParse(mskbxSalBruto.Text, out salBruto))

                        MessageBox.Show("Salário Bruto Inválido");

                    //Cálculo INSS
                    else
                    {
                        if (salBruto <= 0)
                            MessageBox.Show("Salário Bruto deve ser maior que ZERO");
                        else if (salBruto <= 800.47)

                        {
                            txtAliqINSS.Text = "7,65%";
                            descINSS = (0.0765 * salBruto);
                            mskbxDescINSS.Text = descINSS.ToString("C");
                        }
                        else if (salBruto <= 1050.00)
                        {
                            txtAliqINSS.Text = "8,65%";
                            descINSS = (0.0865 * salBruto);
                            mskbxDescINSS.Text = descINSS.ToString("C");
                        }
                        else if (salBruto <= 1400.77)
                        {
                            txtAliqINSS.Text = "9,00%";
                            descINSS = (0.09 * salBruto);
                            mskbxDescINSS.Text = descINSS.ToString("C");
                        }
                        else if (salBruto <= 2801.56)
                        {
                            txtAliqINSS.Text = "11,00%";
                            descINSS = (0.11 * salBruto);
                            mskbxDescINSS.Text = descINSS.ToString("C");
                        }
                        else
                        {
                            txtAliqINSS.Text = "Desconto Fixo";
                            descINSS = 308.17;
                            mskbxDescINSS.Text = descINSS.ToString("C");
                        }

                        //Cálculo IRPF
                        if (salBruto <= 1257.00)
                        {
                            txtAliqIRPF.Text = "Isento";
                            descIRPF = 0.00;
                            mskbxDescIRPF.Text = descIRPF.ToString("C");
                        }
                        else
                        {
                            if (salBruto <= 2512.08)
                            {
                                txtAliqIRPF.Text = "15,00%";
                                descIRPF = (0.15 * salBruto);
                                mskbxDescIRPF.Text = descIRPF.ToString("C");
                            }
                            else
                            {
                                txtAliqIRPF.Text = "27,50%";
                                descIRPF = (0.275 * salBruto);
                                mskbxDescIRPF.Text = descIRPF.ToString("C");
                            }

                            //Salário Família
                        }
                        if (salBruto <= 435.52)
                        {
                            int numFilhos = (int)nudNumFilhos.Value;
                            salFamilia = (numFilhos * 22.33);
                            txtSalFamilia.Text = salFamilia.ToString("C");
                        }
                        else if (salBruto <= 654.61)
                        {
                            int numFilhos = (int)nudNumFilhos.Value;
                            salFamilia = (numFilhos * 15.74);
                            txtSalFamilia.Text = salFamilia.ToString("C");
                        }
                        else
                        {
                            int numFilhos = (int)nudNumFilhos.Value;
                            salFamilia = 0;
                            txtSalFamilia.Text = salFamilia.ToString("C");
                        }
                    }

               
                }
            }
        }
    }
}
