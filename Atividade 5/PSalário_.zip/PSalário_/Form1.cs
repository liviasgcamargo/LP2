﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalário
{
    public partial class Form1 : Form
    {
        double salBruto, salFamilia, descINSS, descIRPF, salLiquido;
        int numFilhos;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text.Length < 10)
            {
                MessageBox.Show("Nome deve ter mais de 10 caracteres");
                txtNome.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalBruto.Text, out salBruto))
            {
                MessageBox.Show("Salário Bruto Inválido");
            }

            else if (salBruto <= 0)
            {
                MessageBox.Show("Salário Bruto deve ser maior que ZERO");
            }

            else
            {
                //Cálculo do INSS

                if (salBruto <= 800.47)
                {
                    txtAliqINSS.Text = "7,65%";
                    descINSS = (0.0765 * salBruto);
                    txtDescINSS.Text = descINSS.ToString("N2");
                }
                else if (salBruto <= 1050.00)
                {
                    txtAliqINSS.Text = "8,65%";
                    descINSS = (0.0865 * salBruto);
                    txtDescINSS.Text = descINSS.ToString("N2");
                }
                else if (salBruto <= 1400.77)
                {
                    txtAliqINSS.Text = "9,00%";
                    descINSS = (0.09 * salBruto);
                    txtDescINSS.Text = descINSS.ToString("N2");
                }
                else if (salBruto <= 2801.56)
                {
                    txtAliqINSS.Text = "11,00%";
                    descINSS = (0.11 * salBruto);
                    txtDescINSS.Text = descINSS.ToString("N2");
                }   
                else
                {
                    txtAliqINSS.Text = "Desconto Fixo";
                    descINSS = 308.17;
                    txtDescINSS.Text = descINSS.ToString("N2");
                }

                //Cálculo do IRPF

                if (salBruto <= 1257.00)
                {
                    txtAliqIRPF.Text = "Isento";
                    descIRPF = 0.00;
                    txtDescIRPF.Text = descIRPF.ToString("N2");
                }
                else if (salBruto <= 2512.08)
                {
                    txtAliqIRPF.Text = "15,00%";
                    descIRPF = (0.15 * salBruto);
                    txtDescIRPF.Text = descIRPF.ToString("N2");
                }
                else
                {
                    txtAliqIRPF.Text = "27,50%";
                    descIRPF = (0.275 * salBruto);
                    txtDescIRPF.Text = descIRPF.ToString("N2");
                }

                //Salário Família
                      
                if (salBruto <= 435.52)
                {
                    int numFilhos = (int)nudNumFilhos.Value;
                    salFamilia = (numFilhos * 22.33);
                    txtSalFamilia.Text = salFamilia.ToString("N2");
                }
                else if (salBruto <= 654.61)
                {
                    int numFilhos = (int)nudNumFilhos.Value;
                    salFamilia = (numFilhos * 15.74);
                    txtSalFamilia.Text = salFamilia.ToString("N2");
                }
                else
                {
                    int numFilhos = (int)nudNumFilhos.Value;
                    salFamilia = 0;
                    txtSalFamilia.Text = salFamilia.ToString("N2");
                }

                //Salário Líquido

                salLiquido = salBruto - descINSS - descIRPF + salFamilia;
                txtSalLiq.Text = salLiquido.ToString("N2");

                //Texto Concatenado

                if (rbtnF.Checked)
                {
                    if (cklbCasado.Checked)
                    {
                        lblDados.Text = "Os descontos do salário da Sra. " + txtNome.Text + " que é casada e que tem: " + (int)nudNumFilhos.Value + " filho(s)";
                    }
                    else
                    {
                        lblDados.Text = "Os descontos do salário da Sra. " + txtNome.Text + " que é solteira e que tem: " + (int)nudNumFilhos.Value + " filho(s)";
                    }
                }
                else if (rbtnM.Checked)
                {
                    if (cklbCasado.Checked)
                    {
                        lblDados.Text = "Os descontos do salário do Sr. " + txtNome.Text + " que é casado e que tem: " + (int)nudNumFilhos.Value + " filho(s)";
                    }
                    else
                    {
                        lblDados.Text = "Os descontos do salário do Sr. " + txtNome.Text + " que é solteiro e que tem: " + (int)nudNumFilhos.Value + " filho(s)";
                    }
                }
            }
        }
    }
}