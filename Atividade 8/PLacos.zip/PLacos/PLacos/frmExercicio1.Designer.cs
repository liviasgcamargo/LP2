﻿namespace PLacos
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnNumBrancos = new System.Windows.Forms.Button();
            this.btnNumR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxtFrase
            // 
            this.rtxtFrase.Location = new System.Drawing.Point(117, 58);
            this.rtxtFrase.MaxLength = 100;
            this.rtxtFrase.Name = "rtxtFrase";
            this.rtxtFrase.Size = new System.Drawing.Size(506, 136);
            this.rtxtFrase.TabIndex = 0;
            this.rtxtFrase.Text = "";
            // 
            // btnNumBrancos
            // 
            this.btnNumBrancos.Location = new System.Drawing.Point(159, 241);
            this.btnNumBrancos.Name = "btnNumBrancos";
            this.btnNumBrancos.Size = new System.Drawing.Size(136, 79);
            this.btnNumBrancos.TabIndex = 1;
            this.btnNumBrancos.Text = "Número de Espaços em Branco na Frase";
            this.btnNumBrancos.UseVisualStyleBackColor = true;
            this.btnNumBrancos.Click += new System.EventHandler(this.BtnNumBrancos_Click);
            // 
            // btnNumR
            // 
            this.btnNumR.Location = new System.Drawing.Point(301, 241);
            this.btnNumR.Name = "btnNumR";
            this.btnNumR.Size = new System.Drawing.Size(136, 79);
            this.btnNumR.TabIndex = 2;
            this.btnNumR.Text = "Número de Vezes que a Letra R Aparece\r\n";
            this.btnNumR.UseVisualStyleBackColor = true;
            this.btnNumR.Click += new System.EventHandler(this.btnNumR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.Location = new System.Drawing.Point(443, 241);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(136, 79);
            this.btnParLetras.TabIndex = 3;
            this.btnParLetras.Text = "Número de vezes que ocorre um mesmo par de letras na frase";
            this.btnParLetras.UseVisualStyleBackColor = true;
            this.btnParLetras.Click += new System.EventHandler(this.BtnParLetras_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnNumR);
            this.Controls.Add(this.btnNumBrancos);
            this.Controls.Add(this.rtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtFrase;
        private System.Windows.Forms.Button btnNumBrancos;
        private System.Windows.Forms.Button btnNumR;
        private System.Windows.Forms.Button btnParLetras;
    }
}