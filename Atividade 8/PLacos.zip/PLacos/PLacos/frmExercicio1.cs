﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnNumBrancos_Click(object sender, EventArgs e)
        {
            int auxiliar = 0;

            for (int i = 0; i < rtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rtxtFrase.Text[i]))
              
                    auxiliar = auxiliar + 1;

            }

            MessageBox.Show("Existe "+ auxiliar.ToString() + " espaço(s) em branco na frase.");
        }

        private void BtnParLetras_Click(object sender, EventArgs e)
        {
            int numPares = 0;
            for (var i = 0; i < rtxtFrase.Text.Length - 1; i++)
            {
                if (rtxtFrase.Text[i] == rtxtFrase.Text[i + 1])
                    numPares += 1;
            }
            MessageBox.Show("N° pares de letras: " + numPares.ToString());



            /*
            char letraAnterior = '\0';
            int numPares = 0;
            for (var i=0; i<rtxtFrase.Text.Length; i++)
            {
                if (rtxtFrase.Text[i] == letraAnterior)
                    numPares += 1;

                letraAnterior = rtxtFrase.Text[i];
            }

            MessageBox.Show("N° pares de letras: " +numPares.ToString());
            */
        }

        private void btnNumR_Click(object sender, EventArgs e)
        {

            int auxiliar = 0; 
            
            char[] Frase = rtxtFrase.Text.ToCharArray();

            foreach (char c in rtxtFrase.Text)
            {


                if (char.ToUpper(c) == 'R')
                    auxiliar += 1;

            }

            MessageBox.Show("A letra R aparece " + auxiliar.ToString() + " vez(es) na frase.");


            //Como mostrar os elementos de um Array pelo mbox
            /*for (int i = 0; i < Frase.Length; i++)
                MessageBox.Show(Frase[i].ToString());

            lembrar disso para o botão 2
            if (char.ToUpper(rtxtFrase.Text[i] == 'R');

            if (char.isWhiteSpace(rtxtFrase.Text[i])); */

        }



    }
}
