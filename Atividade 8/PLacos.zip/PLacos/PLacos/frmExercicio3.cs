﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificacao_Click(object sender, EventArgs e)
        {
            string caracter = "";
            string caracterReverse = "";

            for (int i = 0; i < txtSequencia.Text.Length; i++)
            {
                if (!char.IsWhiteSpace(txtSequencia.Text[i]))
                    caracter += char.ToUpper(txtSequencia.Text[i]);
            }

            for (int i = txtSequencia.Text.Length- 1; i >= 0; i--)
            {
                if (!char.IsWhiteSpace(txtSequencia.Text[i]))
                    caracterReverse += char.ToUpper(txtSequencia.Text[i]);
            }
            if (caracter == caracterReverse)
                MessageBox.Show("É um Palíndromo");
            else
                MessageBox.Show("Não é um Palíndromo");
        }
    }
}