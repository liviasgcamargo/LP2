﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnH_Click(object sender, EventArgs e)
        {
           /* int numero = 0;
            if (int.TryParse(txtNumN.Text, out numero))
            {
                if (numero <= 0)
                    MessageBox.Show("Número deve ser maior que zero");

                else
                {
                    double h = 0;

                    for (var i = 1; i <= numero; i++)
                        h += 1 / (double)i;

                    MessageBox.Show("Valor de H = " + h.ToString());
                }
            }*/


            double H = 0;
            int numeroN = 0;
         
            if (!int.TryParse(txtNumN.Text, out numeroN) && (numeroN <= 0))
            {
                MessageBox.Show("Valor Inválido. \n digite apenas Números, e que sejam MAIORES do que ZERO");

            }

            else
            {
                for (var i = 1; i <= numeroN; i++)
                {
                    H += 1 / (double)i;
                }
            }

            MessageBox.Show("Valor de H = " + H.ToString());


            //no botão 3, tirar espaços em branco, deixar tudo em maiusculo... padronizar. Irá utilizar o Reverse do array, ou seja, transformar a frase em vetor!
            //Fazer um programa para gerar o número H. O número N será fornecido em umTextBox. Testar se N é maior que 0. H = 1 + 1 / 2 + 1 / 3 + 1 / 4 + 1 / 5 + ...+1 / N, utilizar instruções For.
        }
    }
}
