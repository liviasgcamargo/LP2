﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PLacos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double salario, gratificacao = 0, salBruto = 0;
            int producao = 0;

            if (double.TryParse(txtSalario.Text, out salario))
            {
                if (int.TryParse(txtProducao.Text, out producao))
                {
                    if (double.TryParse(txtGratificacao.Text, out gratificacao))
                    {
                        if (producao >= 150)
                        {
                            salBruto = salario + salario * (0.05 * 1 + 0.1 * 1 + 0.1 * 1) + gratificacao;
                        }
                        else
                        {
                            if (producao >= 120)
                            {
                                salBruto = salario + salario * (0.05 * 1 + 0.1 * 1) + gratificacao;
                            }
                            else
                            {
                                if (producao >= 100)
                                {
                                    salBruto = salario + salario * (0.05 * 1) + gratificacao;
                                }
                                else
                                {
                                    salBruto = salario + gratificacao;
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Insira um valor maior ou igual a ZERO");
                    }
                }
                else
                {
                    MessageBox.Show("Insira um valor maior ou igual a ZERO");
                }
            }
            else
            {
                MessageBox.Show("Valor inválido: digite apenas valores numéricos maiores do que ZERO");
            }

            if (salBruto > 7000.0)
            {
                if (producao < 150)
                {
                    if (gratificacao == 0)
                    {
                        MessageBox.Show("Salário acima de R$7000,00 apenas é disponibilizado para \nfuncionários com produção maior ou igual à 150 e com gratificação.\nPor favor, verifique a entrada de valores.");

                    }
                }
            }
            else
            {
                    MessageBox.Show("O Salário Bruto do(a) Funcionário(a) " + txtNome.Text + " é igual à " + salBruto.ToString("N2"));
            }
        }
    }
}
