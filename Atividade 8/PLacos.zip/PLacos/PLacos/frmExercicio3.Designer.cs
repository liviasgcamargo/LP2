﻿namespace PLacos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSequencia = new System.Windows.Forms.TextBox();
            this.btnVerificacao = new System.Windows.Forms.Button();
            this.lblSequencia = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtSequencia
            // 
            this.txtSequencia.Location = new System.Drawing.Point(252, 90);
            this.txtSequencia.MaxLength = 50;
            this.txtSequencia.Name = "txtSequencia";
            this.txtSequencia.Size = new System.Drawing.Size(281, 20);
            this.txtSequencia.TabIndex = 0;
            // 
            // btnVerificacao
            // 
            this.btnVerificacao.Location = new System.Drawing.Point(315, 144);
            this.btnVerificacao.Name = "btnVerificacao";
            this.btnVerificacao.Size = new System.Drawing.Size(155, 43);
            this.btnVerificacao.TabIndex = 1;
            this.btnVerificacao.Text = "Verificar Palíndromo";
            this.btnVerificacao.UseVisualStyleBackColor = true;
            this.btnVerificacao.Click += new System.EventHandler(this.btnVerificacao_Click);
            // 
            // lblSequencia
            // 
            this.lblSequencia.AutoSize = true;
            this.lblSequencia.Location = new System.Drawing.Point(119, 93);
            this.lblSequencia.Name = "lblSequencia";
            this.lblSequencia.Size = new System.Drawing.Size(127, 13);
            this.lblSequencia.TabIndex = 2;
            this.lblSequencia.Text = "Sequência de Caracteres";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSequencia);
            this.Controls.Add(this.btnVerificacao);
            this.Controls.Add(this.txtSequencia);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSequencia;
        private System.Windows.Forms.Button btnVerificacao;
        private System.Windows.Forms.Label lblSequencia;
    }
}