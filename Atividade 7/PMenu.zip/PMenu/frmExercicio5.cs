﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PMenu
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            var r = new System.Random();

            for (var x = 0; x < 1000; x++)
            {
                txtNumero1.Text = r.Next(0, 1000).ToString();
                txtNumero2.Text = r.Next(0, 1000).ToString();
            }

            int numero1 = int.Parse(txtNumero1.Text);
            int numero2 = int.Parse(txtNumero2.Text);

            if (numero1 > numero2)
            {
                MessageBox.Show("Número 1 é o VENCEDOR!");
            }
            else
                MessageBox.Show("Número 2 é o VENCEDOR!");

        }
    }
}
