﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQtdeNumeros_Click(object sender, EventArgs e)
        {
            int posicao, contador = 0;
            string texto = rchtxtTexto.Text;

            for (posicao = 0; posicao < texto.Length; posicao++)
            {
                if (Char.IsNumber(texto[posicao]))
                {
                    contador += 1;
                }
                    
            }
            if (contador == 0)
            {
                MessageBox.Show("Não existem números no texto");
            }
            else
                if (contador == 1)
                 {
                MessageBox.Show("Existe apenas " + contador + " número no texto");
                 }
            else
            {
                MessageBox.Show("Existem " + contador + " números no texto");
            }
        }

        private void btnBranco_Click(object sender, EventArgs e)
        { 
            int posicao = 0;

            while (posicao < rchtxtTexto.Text.Length && !char.IsWhiteSpace(rchtxtTexto.Text[posicao]))
            { 
                posicao = posicao + 1;
            }
            
            if (posicao >=  rchtxtTexto.Text.Length)
            {
                MessageBox.Show("Não existe espaço em branco no texto");
            }
            else
                MessageBox.Show("O primeiro caracter em branco está na posição " + (posicao+1));

        }

        private void btnQtdeLetras_Click(object sender, EventArgs e)
        {
            int posicao = 0, contador = 0;
            string texto = rchtxtTexto.Text;

            foreach (char element in texto)
            {
                if (Char.IsLetter(texto[posicao]))
                {
                    posicao += 1;
                    contador += 1;
                }

            }
            if (contador == 0)
            {
                MessageBox.Show("Não existem letras no texto");
            }
            else
                if (contador == 1)
            {
                MessageBox.Show("Existe apenas " + contador + " letra no texto");
            }
            else
            {
                MessageBox.Show("Existem " + contador + " letras no texto");
            }
        }
    }
}
