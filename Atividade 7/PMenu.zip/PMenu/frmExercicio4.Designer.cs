﻿namespace PMenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnQtdeNumeros = new System.Windows.Forms.Button();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnQtdeLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchtxtTexto.Location = new System.Drawing.Point(248, 66);
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(268, 149);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            // 
            // btnQtdeNumeros
            // 
            this.btnQtdeNumeros.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdeNumeros.Location = new System.Drawing.Point(193, 248);
            this.btnQtdeNumeros.Name = "btnQtdeNumeros";
            this.btnQtdeNumeros.Size = new System.Drawing.Size(105, 68);
            this.btnQtdeNumeros.TabIndex = 1;
            this.btnQtdeNumeros.Text = "Quantidade de Caracteres Numéricos";
            this.btnQtdeNumeros.UseVisualStyleBackColor = true;
            this.btnQtdeNumeros.Click += new System.EventHandler(this.btnQtdeNumeros_Click);
            // 
            // btnBranco
            // 
            this.btnBranco.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranco.Location = new System.Drawing.Point(323, 248);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(105, 68);
            this.btnBranco.TabIndex = 2;
            this.btnBranco.Text = "Primeiro Caracter Branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnQtdeLetras
            // 
            this.btnQtdeLetras.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdeLetras.Location = new System.Drawing.Point(456, 248);
            this.btnQtdeLetras.Name = "btnQtdeLetras";
            this.btnQtdeLetras.Size = new System.Drawing.Size(105, 68);
            this.btnQtdeLetras.TabIndex = 3;
            this.btnQtdeLetras.Text = "Quantidade Caracteres Alfabéticos";
            this.btnQtdeLetras.UseVisualStyleBackColor = true;
            this.btnQtdeLetras.Click += new System.EventHandler(this.btnQtdeLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnQtdeLetras);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.btnQtdeNumeros);
            this.Controls.Add(this.rchtxtTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.Button btnQtdeNumeros;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnQtdeLetras;
    }
}