﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar1 = "";

            for (var i = 0;   i < 20; i++)
            {
                auxiliar1 = Interaction.InputBox("Digite o número " + (i+1).ToString(), "Entrada de Dados");
                if (!int.TryParse(auxiliar1, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
            }

            Array.Reverse (vetor);
            auxiliar1 = "";
            foreach (var j in vetor)
                auxiliar1 += "\n" + j.ToString();
            MessageBox.Show(auxiliar1);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            double faturamento = 0;
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            string auxiliar3 = "";

            for (var i = 0; i < 10; i++)
            {
                auxiliar3 = Interaction.InputBox("Digite Quantidade " + (i + 1).ToString(), "Entrada das Quantidades");

                if (!double.TryParse(auxiliar3, out quantidade[i]))
                {
                    MessageBox.Show("Quantidade Inválida");
                    i--;
                }
                else
                {
                    while (preco[i]<= 0)
                    {
                        auxiliar3 = "";
                        auxiliar3 = Interaction.InputBox("Digite o Preço " + (i + 1).ToString(), "Entrada dos Preços");
                        if (double.TryParse(auxiliar3,out preco[i]))
                        {
                            faturamento += quantidade[i] * preco[i];
                        }
                        else
                        {
                            MessageBox.Show("Preço Inválido");
                        }
                    }
                }
            }
            MessageBox.Show(faturamento.ToString("N2"));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N - 1; I++) { Total += Alunos[I].Length; }
            MessageBox.Show("Total = " + Total.ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ArrayList listaNomes = new ArrayList(){
                "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"
            };
            
            listaNomes.Remove("Otávio");

            foreach (string nome in listaNomes)
            {
                MessageBox.Show(nome.ToString());
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {

            Double[,] notaProva = new double[20, 3];
            string auxiliar2 = "";

            for (int i = 0; i < 20; i++)
            {

                for (int j = 0; j < 3; j++)
                {

                    auxiliar2 = Interaction.InputBox("Digite a Nota da Prova", "Entrada de Dados");
                    if (!double.TryParse(auxiliar2, out notaProva[i, j]))
                    {
                        MessageBox.Show("Valor de Nota Inválida");
                        i--;
                    }
                }
            }

            int x = 0;

            while (x < 20)
            {
                Double media = (notaProva[x, 0] + notaProva[x, 1] + notaProva[x, 2]) / 3;
                MessageBox.Show("Aluno " + (x+1) + " Média = " + media);
                x++;
            }

            
        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }
    }
}
