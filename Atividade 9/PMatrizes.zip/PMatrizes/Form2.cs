﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[1];
            int[] tamanhoReal = new int[1];
            int qtdeBranco = 0;
            string branco = " ";

            for (int i = 0; i < nomes.Length; i++)
            {
                string auxiliar1 = Interaction.InputBox("Digite o Nome" + (i + 1).ToString(), "Entrada de Dados");
                
                
                if (nomes[i].Contains(branco))
                {
                    qtdeBranco = qtdeBranco + 1;
                    tamanhoReal[i] = nomes[i].Length - qtdeBranco;
                }
                else
                    tamanhoReal[i] = nomes[i].Length;
            }

            for (int j = 0; j < 1; j++)
            {
                lstbxNomes.Items.Add("O nome " + nomes[j] + " tem " + tamanhoReal[j] + " caracteres");
            }
        }
    }
}
